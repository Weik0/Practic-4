﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static System.Reflection.Metadata.BlobBuilder;

namespace практическая_работа_4_Батурина
{
    /// <summary>
    /// Логика взаимодействия для MainFrame.xaml
    /// </summary>
    public partial class MainFrame : Page
    {
        public List<Contact> Contacts { get; set; } = new List<Contact>();
        public MainFrame(string fullName)
        {
            InitializeComponent();
            WelcomeMessage.Text = $"Добро пожаловать, {fullName}.";
        }

   
        private void DeleteContactButton_Click_1(object sender, RoutedEventArgs e)
        {
            string contactName = NameOfContactTextBox.Text;
            string contactNumber = NumberOfContactTextBox.Text;

            if (!string.IsNullOrEmpty(contactName) && !string.IsNullOrEmpty(contactNumber))
            {
                Contacts.Add(new Contact { ContactName = contactName, ContactNumber = contactNumber });
                UpdateContactsList();
                NameOfContactTextBox.Clear();
                NumberOfContactTextBox.Clear();
            }
            else
            {
                MessageBox.Show("Введите имя и номер контакта.");
            }
        }

        private void AddContactButton_Click_1(object sender, RoutedEventArgs e)
        {
            if (ContactsList.SelectedItem is Contact selectedContact)
            {
                Contacts.Remove(selectedContact);
                UpdateContactsList();
            }
            else
            {
                MessageBox.Show("Выберите контакт для удаления.");
            }
        }
        private void UpdateContactsList()
        {
            ContactsList.Items.Clear();
            foreach (var Contact in Contacts)
            {
                ContactsList.Items.Add(Contact);
            }
        }
    }
}
