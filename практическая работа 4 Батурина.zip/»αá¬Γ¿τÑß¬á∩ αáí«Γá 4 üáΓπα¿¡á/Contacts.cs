﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace практическая_работа_4_Батурина
{
    public class Contact
    {
        public string ContactName { get; set; }
        public string ContactNumber { get; set; }

        public override string ToString()
        {
            return $" Имя: {ContactName} Номер: {ContactNumber}";
        }
    }
}
