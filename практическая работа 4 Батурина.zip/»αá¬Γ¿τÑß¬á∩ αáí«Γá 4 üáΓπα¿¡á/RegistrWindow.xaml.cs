﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace практическая_работа_4_Батурина
{
    /// <summary>
    /// Логика взаимодействия для RegistrWindow.xaml
    /// </summary>
    public partial class RegistrWindow : Page
    {
        public RegistrWindow()
        {
            InitializeComponent();
        }

        private void RegistrButton_Click(object sender, RoutedEventArgs e)
        {
            string Surname = SurnameTextBox.Text;
            string Name = NameTextBox.Text;
            string SecondName = SecondNameTextBox.Text;
            string DateOfBirth = DateOfBirthTextBox.Text;
            string Email = EmailTextBox.Text;
            string password = PasswordTextBox.Text;
            string ConfirmPassword = ConfirmPasswordTextBox.Text;




            if (password == ConfirmPassword)
            {
                string fullName = $"{SurnameTextBox.Text} {NameTextBox.Text} {SecondNameTextBox.Text}";
                string email = EmailTextBox.Text;

                // создаем нового пользователя
                User newUser = new User
                {
                    FullName = fullName,
                    Email = email,
                    Password = password
                };

                // добавления пользователя в список зарегестрированных 
                MainPage.RegisteredUsers.Add(newUser);

                MessageBox.Show($"{NameTextBox.Text}, вы зарегистрировались!");

                // открываем личный кабинет
                this.NavigationService.Navigate(new MainFrame(fullName));
            }
            else
            {
                MessageBox.Show("Пароли не совпадают.");
            }
        }



    }

}
