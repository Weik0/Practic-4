﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace практическая_работа_4_Батурина
{
    /// <summary>
    /// Логика взаимодействия для MainPage.xaml
    /// </summary>
    public partial class MainPage : Page
    {
        public static List<User> RegisteredUsers = new List<User>();
        public MainPage()
        {
            InitializeComponent();
        }

        private void RegistrButton_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new RegistrWindow());
        }

        private void AutorizButton_Click(object sender, RoutedEventArgs e)
        {
            string email = EmailTextBox.Text;
            string password = PasswordTextBox.Text;

            User user = RegisteredUsers.FirstOrDefault(u => u.Email == email && u.Password == password);

            if (user != null)
            {

                this.NavigationService.Navigate(new MainFrame(user.FullName));
            }
            else
            {
                MessageBox.Show("Неверный E-mail или пароль.");
            }
        }
    }
}
